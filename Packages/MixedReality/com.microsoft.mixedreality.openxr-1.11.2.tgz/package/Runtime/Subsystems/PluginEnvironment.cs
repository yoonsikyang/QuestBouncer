// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System;
using UnityEngine;
using UnityEngine.XR.OpenXR;

namespace Microsoft.MixedReality.OpenXR
{
    //Must match PluginEnvironment in PluginEnvironment.h
    enum PluginEnvironment
    {
        unityVersion = 1 << 0,
        openXRPluginVersion = 1 << 1,
        mrOpenXRPluginVersion = 1 << 2,
        graphicsAPI = 1 << 3,
        sessionCreationResult = 1 << 4,
        appName = 1 << 5,
        appVersion = 1 << 6,
        appMode = 1 << 7,
        openXRRuntimeName = 1 << 8,
        openXRRuntimeVersion = 1 << 9,
        apiVersion = 1 << 10
    };


    internal class PluginEnvironmentSubsystem
    {
        private static bool m_initialized = false;
        private static bool m_nativeUnavailable = false;

        internal static void InitializePlugin()
        {
            if (m_initialized || m_nativeUnavailable)
            {
                return;
            }

#if UNITY_EDITOR_OSX
            m_nativeUnavailable = true;
            return;
#else
            try
            {
                NativeLib.SetPluginEnvironment(PluginEnvironment.unityVersion, Application.unityVersion);
                NativeLib.SetPluginEnvironment(PluginEnvironment.openXRPluginVersion, OpenXRRuntime.pluginVersion);
                NativeLib.SetPluginEnvironment(PluginEnvironment.mrOpenXRPluginVersion, typeof(OpenXRContext).Assembly.GetName().Version.ToString());
                NativeLib.InitializePlugin();
                m_initialized = true;
            }
            catch (DllNotFoundException exception)
            {
                m_nativeUnavailable = true;
                Debug.LogWarning($"Skipping Microsoft OpenXR native initialization because {NativeLib.DllName} is unavailable on this editor platform. {exception.Message}");
            }
#endif
        }

        internal static void OnSessionCreated()
        {
            if (m_nativeUnavailable)
            {
                return;
            }

#if UNITY_EDITOR_OSX
            m_nativeUnavailable = true;
            return;
#else
            string appMode = "undefined";

#if UNITY_EDITOR
            appMode = "PlayMode";
#else
            appMode = "AppMode";
#endif
            NativeLib.SetPluginEnvironment(PluginEnvironment.appName, Application.productName);
            NativeLib.SetPluginEnvironment(PluginEnvironment.appVersion, Application.version);
            NativeLib.SetPluginEnvironment(PluginEnvironment.appMode, appMode);
            NativeLib.SetPluginEnvironment(PluginEnvironment.openXRRuntimeName, OpenXRRuntime.name);
            NativeLib.SetPluginEnvironment(PluginEnvironment.openXRRuntimeVersion, OpenXRRuntime.version);
            NativeLib.SetPluginEnvironment(PluginEnvironment.apiVersion, OpenXRRuntime.apiVersion);
#endif
        }
    }

}
